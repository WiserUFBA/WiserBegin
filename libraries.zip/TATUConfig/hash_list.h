// Developed by Ramon Costa and Jeferson Lima
// DJB2 Const Generator V 1.0

/* System constants */
#define H_PAN_ID 		0xC7405330
#define H_RESET_TIMES 	0x51DB5E69
#define H_START_TIME 	0x2DA64181
#define H_SAMPLE_RATE 	0x8F4B1432
#define H_OS_VERSION 	0x68B6454C
#define H_DEVICE 		0xAB8ED255
#define H_ID 			0x5973F2
#define H_lamp 			2090464143
#define H_valve 		277698403

